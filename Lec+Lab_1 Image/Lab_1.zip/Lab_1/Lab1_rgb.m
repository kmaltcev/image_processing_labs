clear all
clc
Im = imread('lena512.jpg');
%imtool(Im)
figure, imshow(Im)


figure
subplot(2,2,1)
imshow(Im)

RR=Im;
RR(:,:,2)=0;
RR(:,:,3)=0;

GG=Im;
GG(:,:,1)=0;
GG(:,:,3)=0;

BB=Im;
BB(:,:,1)=0;
BB(:,:,2)=0;

subplot(2,2,2)
imshow(RR)
subplot(2,2,3)
imshow(GG)
subplot(2,2,4)
imshow(BB)

