clear all
clc

monkey = imread('monkey.jpg');
%imtool(monkey)

gray_image = rgb2gray(monkey);
binary_image = im2bw(gray_image);

figure
subplot(2,2,1)
imshow(monkey)
subplot(2,2,2)
imshow(gray_image);
subplot(2,2,3)
imshow(binary_image);

f=monkey;
fc0 = f(1:end/2, 1:end/2, :);
subplot(2,2,4)
imshow(fc0);

imwrite(fc0, 'mon.jpg', 'quality', 25)
%fc1=imread('mon.jpg')
%figure,imshow(fc1);
 
fp = f(end:-1:1, :, :);
figure,imshow(fp);

fs = f(1:2:end, 1:2:end,:);
figure,imshow(fs);
